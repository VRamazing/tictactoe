﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class buttonScript : MonoBehaviour {

	public Button button;
	public Text buttonText;

	private GameController gameController;
	private string playerSide = "X";

	public void SetSpace(){
		string whichSide =  gameController.GetPlayerSide();
		if (whichSide == playerSide) {
			buttonText.text = whichSide;
			button.interactable = false;
			gameController.EndTurn ();
		}
	}

	public void SetGameControllerReference(GameController controller){
		gameController = controller;
	}

}
